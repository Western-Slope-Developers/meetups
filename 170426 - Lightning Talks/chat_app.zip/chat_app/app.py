import json
import threading
import gevent
import flask

from flask import Flask, render_template, Response
from gevent.wsgi import WSGIServer

message_log = []

app = Flask(__name__)

@app.route("/")
def hello():
    return render_template('index.html')

@app.route('/message/<message>')
def post_message(message):
	message_log.append(message)
	return ""

@app.route('/messages')
def messages():
	return Response(serve_messages(), mimetype="text/event-stream")

def serve_messages():
	message_counter = 0
	while True:
		print message_log, message_counter
		if (len(message_log) - 1) > message_counter:
			yield 'data: %s\n\n' % message_log[message_counter]
			message_counter += 1
		else:
			gevent.sleep(0.5)


if __name__ == "__main__":
	http_server = WSGIServer(('', 8000), app)
	http_server.serve_forever()
